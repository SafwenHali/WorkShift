module.exports = {
  jwtSecret: "mysecret",
  jwtExpiration: "1h",
};
